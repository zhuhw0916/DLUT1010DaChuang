
library(glmnet)
library(survival)
setwd("..\\Desktop\\dataSet")#�޸�

mydata <- read.csv(file = "g.csv")

v1<- data.matrix(mydata[,c(4,6:16)])
v2 <- data.matrix(mydata[,c(1:3)])

library(showtext)
showtext.auto(enable = TRUE)
font.add('SimSun', 'simsun.ttc')

myfit <- glmnet(v1, v2, family = "mgaussian")
pdf("lambda.pdf")
plot(myfit, xvar = "lambda", label = T,family = 'SimSun')
dev.off()

myfit2 <- cv.glmnet(v1, v2, family="mgaussian")
pdf("min.pdf")
plot(myfit2)
abline(v=log(c(myfit2$lambda.min,myfit2$lambda.1se)),lty="dashed")
dev.off()

myfit2$lambda.min
coe <- coef(myfit2, s = myfit2$lambda.min)
act_index <- which(coe$��Ҷ���غ���..mg.g.!= 0)
act_coe <- coe$��Ҷ���غ���..mg.g.[act_index]
row.names(coe$��Ҷ���غ���..mg.g.)[act_index]
